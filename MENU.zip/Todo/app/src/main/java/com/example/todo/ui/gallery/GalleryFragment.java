package com.example.todo.ui.gallery;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import com.example.todo.R;

import java.util.ArrayList;

public class GalleryFragment extends Fragment {

    private GalleryViewModel galleryViewModel;
    private ListAdapter listItemAdapter;

    private ArrayList<Persona> listaNombres = new ArrayList<>();
    private ListView listView;
    private PersonaLab mPersonaLab;
  //  private ListAdapter listItemAdapter;
    private Persona mPersona;
    private TextView guardar;
    private Button bguardar, blimpiar;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        galleryViewModel =
                ViewModelProviders.of(this).get(GalleryViewModel.class);

        View root = inflater.inflate(R.layout.fragment_gallery, container, false);

        final Button bguardar = root.findViewById(R.id.buttonGuardar);
        blimpiar = (Button) root.findViewById(R.id.buttonLimpiar);
        guardar = (TextView) root.findViewById(R.id.editTextTextPersonName);


        blimpiar.setOnClickListener(new View.OnClickListener() {//limpiador
            @Override
            public void onClick(View view) {
                guardar.setText(null);
            }
        });
        bguardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {//Boton Guardar
                 //insertPersonas();
                //getAllPersonas();
                guardar.setText("Soy Celio");
            }

        });
        //   galleryViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
        // @Override

        // });
        return root;

    }

    public void insertPersonas() {
        mPersona=new Persona();
        mPersona.setNombre(guardar.getText().toString());
        mPersonaLab.addPersona(mPersona);
        guardar.setText(" ");

    }
    // CONSULTA A LA BASE DE DATOS
    public void getAllPersonas(){
        listaNombres.clear();
        listaNombres.addAll(mPersonaLab.getPersonas());

    }

    }
//}
